import { atom } from "jotai";

export const buttonLabelAtom = atom<string>("Update");
