import { atom } from "jotai";

export const dialogVisibleAtom = atom<boolean>(false);
