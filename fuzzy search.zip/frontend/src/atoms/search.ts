import { atom } from "jotai";

export const searchTextAtom = atom<string>("");
