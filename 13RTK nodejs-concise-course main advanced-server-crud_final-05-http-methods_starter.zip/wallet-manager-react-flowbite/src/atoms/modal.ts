import { atom } from "jotai";

export const openModalAtom = atom(false);
