function Loading() {
  return <span className="loading loading-infinity loading-xl"></span>;
}

export default Loading;
